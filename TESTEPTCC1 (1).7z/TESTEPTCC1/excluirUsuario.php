<?php
//conexão Mysql

require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";
//cabeçalho
cabecalho("Exclusão de Usuario");


$USU_ID    = $_GET['USU_ID'];

//prepara o comando para excluir
$delete = $pdo->prepare("delete from TB_USUARIO where USU_ID= :USU_ID");

//vincula as labels com a variável vindas do form
$delete->bindValue(':USU_ID',$USU_ID);

//tenta executar o insert no banco
if($delete->execute()){
    echo "<h1> Usuário excluído! Aguarde... </h1>";
    header("Refresh:2;URL=frmCadUsuario.php");
}else {
    echo "<h1>Erro ao excluir.</h1>";
}
rodape();

?>






