<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesLoginEntrar.php";

//cabeçalho
cabecalho("Resultado da operação");


$USU_NOME       = $_POST['txtUSU_NOME'];
$USU_CELULAR    = $_POST['txtUSU_CELULAR'];
$USU_EMAIL      = $_POST['txtUSU_EMAIL'];
$USU_SENHA      = MD5($_POST['txtUSU_SENHA']);


verificacampo("USU_NOME",$USU_NOME);
verificacampo("USU_CELULAR",$USU_CELULAR);
verificacampo("USU_EMAIL",$USU_EMAIL);
verificacampo("USU_SENHA",$USU_SENHA);

//vERIFICA ATAQUE XSS
$USU_NOME = htmlentities($USU_NOME);

//COMANDO SQL QUE INSERI NA TABELA USUÁRIOS
$insert =$pdo->prepare("insert into TB_USUARIO values(:USU_ID,:USU_NOME,:USU_CELULAR,:USU_EMAIL,:USU_SENHA)");

//vincula as labels com a variável vindas do form
$insert->bindValue(':USU_ID',0);
$insert->bindValue(':USU_NOME',$USU_NOME);
$insert->bindValue(':USU_CELULAR',$USU_CELULAR);
$insert->bindValue(':USU_EMAIL',$USU_EMAIL);
$insert->bindValue(':USU_SENHA',$USU_SENHA);

//tenta executar o insert no banco
if($insert->execute()){
    echo "<h1> Usuário Cadastrado </h1>";
    header("Refresh:2;URL=index.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>




