<?php
        require "funcoesPTCC.php";
        require "configPTCC.php";

        cabecalho("Cadastro");

        echo "<h1>Cadastro de Usuario</h1>
    
          <form action=\"gravaUsuario.php\" method=\"post\" class=\"form-control-inline\">
            <label>NOME
                <input type=\"text\" name=\"txtUSU_NOME\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>CELULAR
                <input type=\"tel\" name=\"txtUSU_CELULAR\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>E-MAIL
                <input type=\"email\" name=\"txtUSU_EMAIL\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>SENHA
                <input type=\"password\" name=\"txtUSU_SENHA\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label> <p>
                <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
                <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
        </form>";

        $consulta = $pdo->prepare("Select * from TB_USUARIO order by USU_ID");
        $consulta->execute();

        echo "<table border class=\"table table-hover\">
        <tr>
           <td>CÓDIGO</td>
           <td>NOME</td>
           <td>CELULAR</td>
           <td>E-MAIL</td>
  
           <td>OPÇÕES</td>
        </tr>";
        
        while ($row=$consulta->fetch(PDO::FETCH_ASSOC)) 
        {
            echo "<tr>";
            echo "<td>$row[USU_ID]</td>";
            echo "<td>$row[USU_NOME]</td>";
            echo "<td>$row[USU_CELULAR]</td>";
            echo "<td>$row[USU_EMAIL]</td>";
        //    echo "<td>$row[USU_SENHA]</td>";
            echo "<td>

            <a href=\"alterarUsuario.php?USU_ID=$row[USU_ID]\" class=\"btn btn-success\">Alterar</a> &nbsp;
            <a href=\"excluirUsuario.php?USU_ID=$row[USU_ID]\" class=\"btn btn-danger\" onclick=\"return confirm('Confirma exclusão do registro?')\">Excluir</a>
            </td>";
            echo "<tr>";
        }
        echo "<table>";
        rodape();
?>



