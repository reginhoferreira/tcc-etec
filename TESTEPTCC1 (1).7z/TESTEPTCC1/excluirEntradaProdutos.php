<?php
//conexão Mysql

require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";
//cabeçalho
cabecalho("Exclusão de Entrada de Produto");


$ENT_ID    = $_GET['ENT_ID'];


//prepara o comando para excluir
$delete = $pdo->prepare("delete from TB_ENTRADA_PRODUTO where ENT_ID= :ENT_ID");

//vincula as labels com a variável vindas do form
$delete->bindValue(':ENT_ID',$ENT_ID);

//tenta executar o insert no banco
if($delete->execute()){
    echo "<h1> Entrada de Produto excluído! Aguarde... </h1>";
    header("Refresh:2;URL=frmEntradaProduto.php");
}else {
    echo "<h1>Erro ao excluir.</h1>";
}
rodape();

?>






