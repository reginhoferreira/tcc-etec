<?php
//conexão Mysql
   require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
   require "funcoesPTCC.php";

   //cabeçalho
   cabecalho("Alteração de Produtos");

   $PRO_ID = $_GET['PRO_ID'];
   $consulta = $pdo->prepare("select * from TB_PRODUTO where PRO_ID = :PRO_ID");
   $consulta->bindValue(':PRO_ID',$PRO_ID);
   $consulta->execute();

   //Busca as informações do banco

   while ($row = $consulta->fetch(PDO::FETCH_ASSOC)) {
       $PRO_ID = $row['PRO_ID'];
       $PRO_DESCRICAO = $row['PRO_DESCRICAO'];
       $PRO_STATUS = $row['PRO_STATUS'];
       $PRO_ESTOQUE_MINIMO = $row['PRO_ESTOQUE_MINIMO'];
       $PRO_ESTOQUE_MAXIMO = $row['PRO_ESTOQUE_MAXIMO'];
   }

//Monta o form com os dados
echo "<h1>Alteração de Produtos</h1>
        
<form action=\"gravaAltProdutos.php\" method=\"post\" class=\"form-control-inline\">
   <input type=\"hidden\" name=\"txtPRO_ID\" value=\"$PRO_ID\">
   <label>DESCRIÇÃO:
      <input type=\"text\" name=\"txtPRO_DESCRICAO\" value=\"$PRO_DESCRICAO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
   <p>
   <select name=\"txtPRO_STATUS\" value=\"$PRO_STATUS\" style=\"width:410px; height: 35px;   margin: 0px;    font-size: 14pt;\" >   
   <option>Status do Produto</option>
   <option value=\"A\">Ativo</option>
   <option value=\"I\">Inativo</option>
</select>


<p>



  <label>ESTOQUE MÍNIMO:
     <input type=\"text\" name=\"txtPRO_ESTOQUE_MINIMO\" value=\"$PRO_ESTOQUE_MINIMO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
  </label><p>
  <label>ESTOQUE MÁXIMO:
  <input type=\"text\" name=\"txtPRO_ESTOQUE_MAXIMO\" value=\"$PRO_ESTOQUE_MAXIMO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
</label><p>
  <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
  <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
</form>";

?>