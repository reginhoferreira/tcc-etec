<?php
        require "funcoesPTCC.php";
        require "configPTCC.php";

        cabecalho("Cadastro");

        echo "<h1>Cadastro de Produto</h1>
        
        <form action=\"gravaProduto.php\" method=\"post\" class=\"form-control-inline\">
            <label>DESCRIÇÃO
                <input type=\"text\" name=\"txtPRO_DESCRICAO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <p>
            <select name=\"txtPRO_STATUS\" style=\"width:410px; height: 35px;   margin: 0px;    font-size: 14pt;\" >   
            <option>Status do Produto</option>
            <option value=\"A\">Ativo</option>
            <option value=\"I\">Inativo</option>
        </select>


<p>
            <label>ESTOQUE MÍNIMO
                <input type=\"text\" name=\"txtPRO_ESTOQUE_MINIMO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>ESTOQUE MÁXIMO
                <input type=\"text\" name=\"txtPRO_ESTOQUE_MAXIMO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label> <p>
                <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
                <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
        </form>";

        $consulta = $pdo->prepare("Select * from TB_PRODUTO order by PRO_ID");
        $consulta->execute();

        echo "<table border class=\"table table-hover\">
        <tr>
           <td>CÓDIGO</td>
           <td>DESCRICAO</td>
           <td>STATUS</td>
           <td>ESTOQUE_MINIMO</td>
           <td>ESTOQUE_MAXIMO</td>
           <td>OPÇÕES</td>
        </tr>";
        
        while ($row=$consulta->fetch(PDO::FETCH_ASSOC)) 
        {
            echo "<tr>";
            echo "<td>$row[PRO_ID]</td>";
            echo "<td>$row[PRO_DESCRICAO]</td>";
            echo "<td>$row[PRO_STATUS]</td>";
            echo "<td>$row[PRO_ESTOQUE_MINIMO]</td>";
            echo "<td>$row[PRO_ESTOQUE_MAXIMO]</td>";
            echo "<td>

            <a href=\"alterarProdutos.php?PRO_ID=$row[PRO_ID]\" class=\"btn btn-success\">Alterar</a> &nbsp;
            <a href=\"excluirprodutos.php?PRO_ID=$row[PRO_ID]\" class=\"btn btn-danger\" onclick=\"return confirm('Confirma exclusão do registro?')\">Excluir</a>
            </td>";
            echo "<tr>";
        }
        echo "<table>";
        rodape();
?>



