<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");

$PRO_ID             = $_POST['txtPRO_ID'];
$PRO_DESCRICAO      = $_POST['txtPRO_DESCRICAO'];
$PRO_STATUS         = $_POST['txtPRO_STATUS'];
$PRO_ESTOQUE_MINIMO = $_POST['txtPRO_ESTOQUE_MINIMO'];
$PRO_ESTOQUE_MAXIMO = $_POST['txtPRO_ESTOQUE_MAXIMO'];

verificacampo("PRO_DESCRICAO",$PRO_DESCRICAO);
verificacampo("PRO_STATUS",$PRO_STATUS);
verificacampo("PRO_ESTOQUE_MINIMO",$PRO_ESTOQUE_MINIMO);
verificacampo("PRO_ESTOQUE_MAXIMO",$PRO_ESTOQUE_MAXIMO);


//COMANDO SQL QUE UPDATE NA TABELA USUÁRIOS
$update =$pdo->prepare("update tb_produto set PRO_DESCRICAO = :PRO_DESCRICAO, PRO_STATUS = :PRO_STATUS, PRO_ESTOQUE_MINIMO = :PRO_ESTOQUE_MINIMO, PRO_ESTOQUE_MAXIMO = :PRO_ESTOQUE_MAXIMO where PRO_ID=:PRO_ID");

//vincula as labels com a variável vindas do form

$update->bindValue(':PRO_DESCRICAO',$PRO_DESCRICAO);
$update->bindValue(':PRO_STATUS',$PRO_STATUS);
$update->bindValue(':PRO_ESTOQUE_MINIMO',$PRO_ESTOQUE_MINIMO);
$update->bindValue(':PRO_ESTOQUE_MAXIMO',$PRO_ESTOQUE_MAXIMO);
$update->bindValue(':PRO_ID',$PRO_ID);

//tenta executar o update no banco
if($update->execute()){
    echo "<h1> Produto Alterado </h1>";
    header("Refresh:2;URL=frmCadProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>






