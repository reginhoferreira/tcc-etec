<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");


$ENT_PRO_ID     = $_POST['txtENT_PRO_ID'];
$ENT_QUANTIDADE = $_POST['txtENT_QUANTIDADE'];
$ENT_VALOR_UNITARIO = $_POST['txtENT_VALOR_UNITARIO'];
$ENT_DATA_ENTRADA = $_POST['txtENT_DATA_ENTRADA'];


verificacampo("ENT_PRO_ID",$ENT_PRO_ID);
verificacampo("ENT_QUANTIDADE",$ENT_QUANTIDADE);
verificacampo("ENT_VALOR_UNITARIO",$ENT_VALOR_UNITARIO);
verificacampo("ENT_DATA_ENTRADA",$ENT_DATA_ENTRADA);

//vERIFICA ATAQUE XSS
$ENT_PRO_ID = htmlentities($ENT_PRO_ID);

//COMANDO SQL QUE INSERI NA TABELA USUÁRIOS
$insert =$pdo->prepare("insert into TB_ENTRADA_PRODUTO values(:ENT_ID,:ENT_PRO_ID,:ENT_QUANTIDADE,:ENT_VALOR_UNITARIO,:ENT_DATA_ENTRADA)");

//vincula as labels com a variável vindas do form
$insert->bindValue(':ENT_ID',0);
$insert->bindValue(':ENT_PRO_ID',$ENT_PRO_ID);
$insert->bindValue(':ENT_QUANTIDADE',$ENT_QUANTIDADE);
$insert->bindValue(':ENT_VALOR_UNITARIO',$ENT_VALOR_UNITARIO);
$insert->bindValue(':ENT_DATA_ENTRADA',$ENT_DATA_ENTRADA);


//tenta executar o insert no banco
if($insert->execute()){
    echo "<h1> Entrada de Produto Cadastrado </h1>";
    header("Refresh:2;URL=frmEntradaProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>




