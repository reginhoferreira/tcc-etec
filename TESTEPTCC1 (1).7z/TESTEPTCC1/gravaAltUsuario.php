<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");

$USU_ID         = $_POST['txtUSU_ID'];
$USU_NOME       = $_POST['txtUSU_NOME'];
$USU_CELULAR    = $_POST['txtUSU_CELULAR'];
$USU_EMAIL      = $_POST['txtUSU_EMAIL'];
$USU_SENHA      = MD5($_POST['txtUSU_SENHA']);

verificacampo("USU_NOME",$USU_NOME);
verificacampo("USU_CELULAR",$USU_CELULAR);
verificacampo("USU_EMAIL",$USU_EMAIL);
verificacampo("USU_SENHA",$USU_SENHA);


//COMANDO SQL QUE UPDATE NA TABELA USUÁRIOS
$update =$pdo->prepare("update TB_USUARIO set USU_NOME = :USU_NOME, USU_CELULAR= :USU_CELULAR, USU_EMAIL = :USU_EMAIL, USU_SENHA = :USU_SENHA where USU_ID=:USU_ID");

//vincula as labels com a variável vindas do form

$update->bindValue(':USU_NOME',$USU_NOME);
$update->bindValue(':USU_CELULAR',$USU_CELULAR);
$update->bindValue(':USU_EMAIL',$USU_EMAIL);
$update->bindValue(':USU_SENHA',$USU_SENHA);
$update->bindValue(':USU_ID',$USU_ID);

//tenta executar o update no banco
if($update->execute()){
    echo "<h1> Usuario Alterado </h1>";
    header("Refresh:2;URL=frmCadUsuario.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>






