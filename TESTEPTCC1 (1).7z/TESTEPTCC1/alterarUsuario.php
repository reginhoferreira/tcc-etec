<?php
//conexão Mysql
   require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
   require "funcoesPTCC.php";

   //cabeçalho
   cabecalho("Alteração de Usuario");

   $USU_ID = $_GET['USU_ID'];
   $consulta = $pdo->prepare("select * from TB_USUARIO where USU_ID = :USU_ID");
   $consulta->bindValue(':USU_ID',$USU_ID);
   $consulta->execute();

   //Busca as informações do banco

   while ($row = $consulta->fetch(PDO::FETCH_ASSOC)) {
       $USU_ID = $row['USU_ID'];
       $USU_NOME = $row['USU_NOME'];
       $USU_CELULAR = $row['USU_CELULAR'];
       $USU_EMAIL   = $row['USU_EMAIL'];
       $USU_SENHA = $row['USU_SENHA'];
   }

//Monta o form com os dados
echo "<h1>Alteração de Usuario</h1>
        
<form action=\"gravaAltUsuario.php\" method=\"post\" class=\"form-control-inline\">
   <input type=\"hidden\" name=\"txtUSU_ID\" value=\"$USU_ID\">
   <label>NOME
      <input type=\"text\" name=\"txtUSU_NOME\" value=\"$USU_NOME\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
   <label>CELULAR
      <input type=\"text\" name=\"txtUSU_CELULAR\" value=\"$USU_CELULAR\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
  <label>E-MAIL
     <input type=\"text\" name=\"txtUSU_EMAIL\" value=\"$USU_EMAIL\" size=\"50\" maxlength=\"100\" class=\"form-control\">
  </label><p>
  <label>SENHA
  <input type=\"password\" name=\"txtUSU_SENHA\" value=\"$USU_SENHA\" size=\"50\" maxlength=\"100\" class=\"form-control\">
</label><p>
  <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
  <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
</form>";

?>