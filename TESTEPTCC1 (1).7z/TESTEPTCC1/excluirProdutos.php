<?php
//conexão Mysql

require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";
//cabeçalho
cabecalho("Exclusão de Produto");


$PRO_ID    = $_GET['PRO_ID'];
$EST_PRO_ID    = $_GET['PRO_ID'];

//prepara o comando para excluir
$delete = $pdo->prepare("delete from TB_ESTOQUE where EST_PRO_ID= :EST_PRO_ID");

//vincula as labels com a variável vindas do form
$delete->bindValue(':EST_PRO_ID',$EST_PRO_ID);

$delete->execute();

$delete = $pdo->prepare("delete from TB_PRODUTO where PRO_ID= :PRO_ID");

//vincula as labels com a variável vindas do form
$delete->bindValue(':PRO_ID',$PRO_ID);



//tenta executar o insert no banco
if($delete->execute()){
    echo "<h1> Produto excluído! Aguarde... </h1>";
    header("Refresh:2;URL=frmCadProduto.php");
}else {
    echo "<h1>Erro ao excluir.</h1>";
}
rodape();

?>






