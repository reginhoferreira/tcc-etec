<?php
//conexão Mysql
   require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
   require "funcoesPTCC.php";

   //cabeçalho
   cabecalho("Alteração de Saida de Produtos");

   $SAI_ID = $_GET['SAI_ID'];
   $consulta = $pdo->prepare("select * from TB_SAIDA_PRODUTO where SAI_ID = :SAI_ID ");
   $consulta->bindValue(':SAI_ID',$SAI_ID);
   $consulta->execute();

   //Busca as informações do banco

   while ($row = $consulta->fetch(PDO::FETCH_ASSOC)) {
       $SAI_PRO_ID  = $row['SAI_PRO_ID'];
       $SAI_QUANTIDADE = $row['SAI_QUANTIDADE'];
       $SAI_VALOR_UNITARIO = $row['SAI_VALOR_UNITARIO'];
       $SAI_DATA_SAIDA = $row['SAI_DATA_SAIDA'];
       $SAI_ID  = $row['SAI_ID'];
   }
   
//Monta o form com os dados
echo "<h1>Alteração Saída de Produtos</h1>
        
<form action=\"gravaAltSaidaProduto.php\" method=\"post\" class=\"form-control-inline\">
   <input type=\"hidden\" name=\"txtSAI_ID\" value=\"$SAI_ID\">
   <label>CÓDIGO:
   <input type=\"text\" name=\"txtSAI_PRO_ID\" value=\"$SAI_PRO_ID\" size=\"50\" maxlength=\"100\" class=\"form-control\">
</label><p>
   <label>QUANTIDADE:
      <input type=\"text\" name=\"txtSAI_QUANTIDADE\" value=\"$SAI_QUANTIDADE\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
   <label>VALOR UNITARIO:
      <input type=\"text\" name=\"txtSAI_VALOR_UNITARIO\" value=\"$SAI_VALOR_UNITARIO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
  <label>DATA ENTRADA:
     <input type=\"text\" name=\"txtSAI_DATA_SAIDA\" value=\"$SAI_DATA_SAIDA\" size=\"50\" maxlength=\"100\" class=\"form-control\">
  </label><p>
  <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
  <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
</form>";

?>