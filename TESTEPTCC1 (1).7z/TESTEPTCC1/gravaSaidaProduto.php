<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");


$SAI_PRO_ID     = $_POST['txtSAI_PRO_ID'];
$SAI_QUANTIDADE = $_POST['txtSAI_QUANTIDADE'];
$SAI_VALOR_UNITARIO = $_POST['txtSAI_VALOR_UNITARIO'];
$SAI_DATA_SAIDA = $_POST['txtSAI_DATA_SAIDA'];


verificacampo("SAI_PRO_ID",$SAI_PRO_ID);
verificacampo("SAI_QUANTIDADE",$SAI_QUANTIDADE);
verificacampo("SAI_VALOR_UNITARIO",$SAI_VALOR_UNITARIO);
verificacampo("SAI_DATA_SAIDA",$SAI_DATA_SAIDA);

//vERIFICA ATAQUE XSS
$SAI_PRO_ID = htmlentities($SAI_PRO_ID);

//COMANDO SQL QUE INSERI NA TABELA USUÁRIOS
$insert =$pdo->prepare("insert into TB_SAIDA_PRODUTO values(:SAI_ID,:SAI_PRO_ID,:SAI_QUANTIDADE,:SAI_DATA_SAIDA,:SAI_VALOR_UNITARIO)");

//vincula as labels com a variável vindas do form
$insert->bindValue(':SAI_ID',0);
$insert->bindValue(':SAI_PRO_ID',$SAI_PRO_ID);
$insert->bindValue(':SAI_QUANTIDADE',$SAI_QUANTIDADE);
$insert->bindValue(':SAI_DATA_SAIDA',$SAI_DATA_SAIDA);
$insert->bindValue(':SAI_VALOR_UNITARIO',$SAI_VALOR_UNITARIO);



//tenta executar o insert no banco
if($insert->execute()){
    echo "<h1> Saída de Produto Cadastrado </h1>";
    header("Refresh:2;URL=frmSaidaProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>



