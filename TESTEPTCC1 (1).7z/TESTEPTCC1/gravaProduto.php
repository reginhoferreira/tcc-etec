<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");


$PRO_DESCRICAO    = $_POST['txtPRO_DESCRICAO'];
$PRO_STATUS     = $_POST['txtPRO_STATUS'];
$PRO_ESTOQUE_MINIMO = $_POST['txtPRO_ESTOQUE_MINIMO'];
$PRO_ESTOQUE_MAXIMO = $_POST['txtPRO_ESTOQUE_MAXIMO'];


verificacampo("PRO_DESCRICAO",$PRO_DESCRICAO);
verificacampo("PRO_STATUS",$PRO_STATUS);
verificacampo("PRO_ESTOQUE_MINIMO",$PRO_ESTOQUE_MINIMO);
verificacampo("PRO_ESTOQUE_MAXIMO",$PRO_ESTOQUE_MAXIMO);

//vERIFICA ATAQUE XSS
$PRO_DESCRICAO = htmlentities($PRO_DESCRICAO);

//COMANDO SQL QUE INSERI NA TABELA USUÁRIOS
$insert =$pdo->prepare("insert into TB_PRODUTO values(:PRO_ID,:PRO_STATUS,:PRO_DESCRICAO,:PRO_ESTOQUE_MINIMO,:PRO_ESTOQUE_MAXIMO)");

//vincula as labels com a variável vindas do form
$insert->bindValue(':PRO_ID',0);
$insert->bindValue(':PRO_STATUS',$PRO_STATUS);
$insert->bindValue(':PRO_DESCRICAO',$PRO_DESCRICAO);
$insert->bindValue(':PRO_ESTOQUE_MINIMO',$PRO_ESTOQUE_MINIMO);
$insert->bindValue(':PRO_ESTOQUE_MAXIMO',$PRO_ESTOQUE_MAXIMO);

//tenta executar o insert no banco
if($insert->execute()){
    echo "<h1> Produto Cadastrado </h1>";
    header("Refresh:2;URL=frmCadProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>




