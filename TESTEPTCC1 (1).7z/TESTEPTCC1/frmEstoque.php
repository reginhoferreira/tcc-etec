<?php
        require "funcoesPTCC.php";
        require "configPTCC.php";

        cabecalho("Cadastro");

        echo "<h1>ESTOQUE DOS PRODUTOS</h1>";

        $consulta = $pdo->prepare("Select * from tb_estoque,tb_produto where est_pro_id = pro_id order by pro_descricao");
        $consulta->execute();

        echo "<table border class=\"table table-hover\">
        <tr>
           <td>ID</td>
           <td>CÓDIGO</td>
           <td>DESCRIÇÃO</td>
           <td>QUANTIDADE</td>
           <td>VALOR UNITÁRIO</td>
        </tr>";
        
        while ($row=$consulta->fetch(PDO::FETCH_ASSOC)) 
        {
            echo "<tr>";
            echo "<td>$row[EST_ID]</td>";
            echo "<td>$row[EST_PRO_ID]</td>";
            echo "<td>$row[PRO_DESCRICAO]</td>";
            echo "<td>$row[EST_QUANTIDADE]</td>";
            echo "<td>$row[EST_VALOR_UNITARIO]</td>";

            echo "<tr>";
        }
        echo "<table>";
        rodape();
?>


