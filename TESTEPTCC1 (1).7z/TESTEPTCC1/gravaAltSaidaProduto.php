<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");


$SAI_PRO_ID          = $_POST['txtSAI_PRO_ID'];
$SAI_QUANTIDADE      = $_POST['txtSAI_QUANTIDADE'];
$SAI_VALOR_UNITARIO  = $_POST['txtSAI_VALOR_UNITARIO'];
$SAI_DATA_SAIDA      = $_POST['txtSAI_DATA_SAIDA'];


verificacampo("SAI_PRO_ID",$SAI_PRO_ID);
verificacampo("SAI_QUANTIDADE",$SAI_QUANTIDADE);
verificacampo("SAI_VALOR_UNITARIO",$SAI_VALOR_UNITARIO);
verificacampo("SAI_DATA_SAIDA",$SAI_DATA_SAIDA);


//COMANDO SQL QUE UPDATE NA TABELA USUÁRIOS
$update =$pdo->prepare("update tb_saida_produto set SAI_QUANTIDADE   = :SAI_QUANTIDADE  , SAI_VALOR_UNITARIO = :SAI_VALOR_UNITARIO, SAI_DATA_SAIDA = :SAI_DATA_SAIDA where SAI_PRO_ID=:SAI_PRO_ID");

//vincula as labels com a variável vindas do form

$update->bindValue(':SAI_QUANTIDADE',$SAI_QUANTIDADE);
$update->bindValue(':SAI_VALOR_UNITARIO',$SAI_VALOR_UNITARIO);
$update->bindValue(':SAI_DATA_SAIDA',$SAI_DATA_SAIDA);
$update->bindValue(':SAI_PRO_ID',$SAI_PRO_ID);

//tenta executar o update no banco
if($update->execute()){
    echo "<h1> Saida Produto Alterado </h1>";
    header("Refresh:2;URL=frmCadProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>






