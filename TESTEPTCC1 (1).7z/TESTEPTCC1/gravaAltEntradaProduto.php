<?php
//conexão Mysql
require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";

//cabeçalho
cabecalho("Resultado da operação");


$ENT_PRO_ID          = $_POST['txtENT_PRO_ID'];
$ENT_QUANTIDADE      = $_POST['txtENT_QUANTIDADE'];
$ENT_VALOR_UNITARIO  = $_POST['txtENT_VALOR_UNITARIO'];
$ENT_DATA_ENTRADA    = $_POST['txtENT_DATA_ENTRADA'];


verificacampo("ENT_PRO_ID",$ENT_PRO_ID);
verificacampo("ENT_QUANTIDADE",$ENT_QUANTIDADE);
verificacampo("ENT_VALOR_UNITARIO",$ENT_VALOR_UNITARIO);
verificacampo("ENT_DATA_ENTRADA",$ENT_DATA_ENTRADA);


//COMANDO SQL QUE UPDATE NA TABELA USUÁRIOS
$update =$pdo->prepare("update tb_entrada_produto set ENT_QUANTIDADE   = :ENT_QUANTIDADE  , ENT_VALOR_UNITARIO = :ENT_VALOR_UNITARIO, ENT_DATA_ENTRADA = :ENT_DATA_ENTRADA where ENT_PRO_ID=:ENT_PRO_ID");

//vincula as labels com a variável vindas do form

$update->bindValue(':ENT_QUANTIDADE',$ENT_QUANTIDADE);
$update->bindValue(':ENT_VALOR_UNITARIO',$ENT_VALOR_UNITARIO);
$update->bindValue(':ENT_DATA_ENTRADA',$ENT_DATA_ENTRADA);
$update->bindValue(':ENT_PRO_ID',$ENT_PRO_ID);

//tenta executar o update no banco
if($update->execute()){
    echo "<h1> Entrada Produto Alterado </h1>";
    header("Refresh:2;URL=frmCadProduto.php");
}else {
    echo "<h1>Erro ao cadastrar.</h1>";
}
rodape();

?>






