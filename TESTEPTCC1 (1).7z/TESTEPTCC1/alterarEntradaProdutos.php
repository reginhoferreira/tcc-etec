<?php
//conexão Mysql
   require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
   require "funcoesPTCC.php";

   //cabeçalho
   cabecalho("Alteração de Entrada de Produtos");

   $ENT_ID = $_GET['ENT_ID'];
   $consulta = $pdo->prepare("select * from TB_ENTRADA_PRODUTO where ENT_ID = :ENT_ID ");
   $consulta->bindValue(':ENT_ID',$ENT_ID);
   $consulta->execute();

   //Busca as informações do banco

   while ($row = $consulta->fetch(PDO::FETCH_ASSOC)) {
       $ENT_PRO_ID  = $row['ENT_PRO_ID'];
       $ENT_QUANTIDADE = $row['ENT_QUANTIDADE'];
       $ENT_VALOR_UNITARIO = $row['ENT_VALOR_UNITARIO'];
       $ENT_DATA_ENTRADA = $row['ENT_DATA_ENTRADA'];
       $ENT_ID  = $row['ENT_ID'];
   }

//Monta o form com os dados
echo "<h1>Alteração Entrada de Produtos</h1>
        
<form action=\"gravaAltEntradaProduto.php\" method=\"post\" class=\"form-control-inline\">
   <input type=\"hidden\" name=\"txtENT_ID\" value=\"$ENT_ID\">
   <label>CÓDIGO:
   <input type=\"text\" name=\"txtENT_PRO_ID\" value=\"$ENT_PRO_ID\" size=\"50\" maxlength=\"100\" class=\"form-control\">
</label><p>
   <label>QUANTIDADE:
      <input type=\"text\" name=\"txtENT_QUANTIDADE\" value=\"$ENT_QUANTIDADE\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
   <label>VALOR UNITARIO:
      <input type=\"text\" name=\"txtENT_VALOR_UNITARIO\" value=\"$ENT_VALOR_UNITARIO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
   </label><p>
  <label>DATA ENTRADA:
     <input type=\"text\" name=\"txtENT_DATA_ENTRADA\" value=\"$ENT_DATA_ENTRADA\" size=\"50\" maxlength=\"100\" class=\"form-control\">
  </label><p>
  <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
  <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
</form>";

?>