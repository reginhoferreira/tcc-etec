<?php
//conexão Mysql

require "configPTCC.php";

//importa funções cabeçalho, rodape, menu
require "funcoesPTCC.php";
//cabeçalho
cabecalho("Exclusão de Saída de Produto");


$SAI_ID    = $_GET['SAI_ID'];


//prepara o comando para excluir
$delete = $pdo->prepare("delete from TB_SAIDA_PRODUTO where SAI_ID= :SAI_ID");

//vincula as labels com a variável vindas do form
$delete->bindValue(':SAI_ID',$SAI_ID);

//tenta executar o insert no banco
if($delete->execute()){
    echo "<h1> Saída de Produto excluído! Aguarde... </h1>";
    header("Refresh:2;URL=frmSaidaProduto.php");
}else {
    echo "<h1>Erro ao excluir.</h1>";
}
rodape();

?>






