<?php

        require "funcoesPTCC.php";
        require "configPTCC.php";

        cabecalho("Cadastro");

        echo "<h1>SAÍDA DE PRODUTO</h1>

        <form action=\"gravaSaidaProduto.php\" method=\"post\" class=\"form-control-inline\"> ";


        #SELECIONA OS PRODUTOS PARA O COMBOBOX
        $comboProdutoSel = $pdo->prepare("SELECT PRO_ID,PRO_DESCRICAO FROM TB_PRODUTO ORDER BY PRO_DESCRICAO");
        $comboProdutoSel->execute();
        
        echo " <p> ";
        echo " <p> ";
       
       #INICIO DO COMBOBOX 
        echo "   <select name=\"txtSAI_PRO_ID\"     style=\"width:410px; height: 35px;   margin: 0px;    font-size: 14pt;\" >   ";
        echo "   <option>SELECIONE O PRODUTO</option>    ";
             
         while ($row=$comboProdutoSel->fetch(PDO::FETCH_ASSOC))  
         {     
         echo " <option value=\"$row[PRO_ID]\">  $row[PRO_DESCRICAO] </option> ";
         }    
             
          echo " </select>";
       #FIM DO COMBOBOX

       echo " 
       <p>
            <label>QUANTIDADE
                 <input type=\"text\" name=\"txtSAI_QUANTIDADE\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>VALOR UNITÁRIO
                <input type=\"text\" name=\"txtSAI_VALOR_UNITARIO\" size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
            <label>DATA DA SAÍDA
                <input type=\"date\" name=\"txtSAI_DATA_SAIDA\"  size=\"50\" maxlength=\"100\" class=\"form-control\">
            </label><p>
                 <input type=\"submit\" value=\"Gravar\" class=\"btn btn-primary\">
                 <input type=\"reset\" value=\"Limpar\" class=\"btn btn-primary\">
        </form>";

        $consulta = $pdo->prepare("Select * from TB_SAIDA_PRODUTO, TB_PRODUTO where SAI_PRO_ID = PRO_ID order by PRO_DESCRICAO");
        $consulta->execute();

        echo "<table border class=\"table table-hover\">
        <tr>
           <td>ID</td>
           <td>CÓDIGO</td>
           <td>DESCRIÇÃO</td>
           <td>QUANTIDADE</td>
           <td>VALOR UNITÁRIO</td>
           <td>DATA DA SAÍDA</td>
           <td>OPÇÕES</td>
        </tr>";
        
        while ($row=$consulta->fetch(PDO::FETCH_ASSOC)) 
        {
            echo "<tr>";
            echo "<td>$row[SAI_PRO_ID]</td>";
            echo "<td>$row[PRO_ID]</td>";
            echo "<td>$row[PRO_DESCRICAO]</td>";
            echo "<td>$row[SAI_QUANTIDADE]</td>";
            echo "<td>$row[SAI_VALOR_UNITARIO]</td>";
            echo "<td>$row[SAI_DATA_SAIDA]</td>";
            echo "<td>

            <a href=\"alterarsaidaprodutos.php?SAI_ID=$row[SAI_ID]\" class=\"btn btn-success\">Alterar</a> &nbsp;
            <a href=\"excluirsaidaprodutos.php?SAI_ID=$row[SAI_ID]\" class=\"btn btn-danger\" onclick=\"return confirm('Confirma exclusão do registro?')\">Excluir</a>
            </td>";
            echo "<tr>";
        }
        echo "<table>";
        rodape();
?>


